#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记

import os
import sys
path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# print(path)
sys.path.insert(0, path)
import pymysql
from conf.settings import MYSQL_HOST
from conf.settings import MYSQL_PORT
from conf.settings import MYSQL_DB_USER
from conf.settings import MYSQL_DB_PASSWORD
from conf.settings import MYSQL_DB_NAME


class DbOperate(object):
    __instance = None

    def __new__(cls, *args, **kwargs):
        if not cls.__instance: 
            cls.__instance = object.__new__(cls)
        return cls.__instance

    def __init__(self, sql):
        self.sql = sql.strip().lower()


    def conn_mysql(self):
        try:
            conn = pymysql.connect(host=MYSQL_HOST,
                                   user=MYSQL_DB_USER,
                                   password=MYSQL_DB_PASSWORD,
                                   db=MYSQL_DB_NAME,
                                   charset='utf8',
                                   port=MYSQL_PORT)
            print(conn)
        except Exception as e:
            print('mysql连接出错,错误信息为%s' % e)
            return {"msg": 'mysql连接出错,错误信息为%s' % e}
        else:
            cur = conn.cursor(cursor=pymysql.cursors.DictCursor)
            # cur = conn.cursor()

        if self.sql.startswith('select'):
            res = None
            try:
                cur.execute(sql)
                res = cur.fetchone()
            except Exception as e:
                msg = "sql执行出错，请检查sql,错误信息为：%s" % e
                res = {"msg": msg}
            finally:
                cur.close()
                conn.close()
                return res

        if self.sql.startswith('delete') or sql.startswith('insert') or sql.startswith('update'):
            try:
                cur.execute(sql)
            except Exception as e:
                msg = "sql执行出错，请检查sql,错误信息为：%s" % e
                return {"msg": msg}
            else:
                conn.commit()
            finally:
                cur.close()
                conn.close()
                return {"msg": "success"}


if __name__ == '__main__':
    sql = "select * from users t where t.username = 'qzcsbj'"
    ret = DbOperate(sql).conn_mysql()
    print(ret)
