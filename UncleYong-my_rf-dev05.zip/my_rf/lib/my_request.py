#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记


# from lib.saveGlobalVariable import save_global_variable

from lib.global_variables import gv
from lib.parameter_substitution import parameter_substitution
from lib.assert_res import assert_res
import requests


def my_request(url, method, headers, cookies, params, body, globalVariable, assertRes, init_sql):
    '''请求'''

    # 可能参数化的地方是url，headers，cookies, params, body
    url = parameter_substitution(url)
    headers = parameter_substitution(headers)
    cookies = parameter_substitution(cookies)
    params = parameter_substitution(params)
    body = parameter_substitution(body)

    # 转换
    headers_ = eval(headers) if headers else headers
    cookies_ = eval(cookies) if cookies else cookies
    params_ = eval(params) if params else params
    body_ = eval(body) if body else body

    if init_sql:
        pass

    # get请参考post完善
    if method.upper() == 'GET':
        try:
            res = requests.get(url=url,headers=headers_, cookies=cookies_, params=params_,timeout=10)
            return res.text
        except Exception as e:
            print('出错了，错误是%s' % e)
            raise e


    elif method.upper() == 'POST':
        # 执行请求
        try:
            res = requests.post(url=url,headers=headers_, cookies=cookies_, params=params_, json=body_, timeout=10)
            # print("执行请求后，结果是： ", res.text)
            # 如果有需要被后续请求用的变量数据
            if globalVariable:
                gv.save_global_variable(globalVariable,res.text)

            # 断言
            res_status = 'pass'
            if assertRes:
                res_status = assert_res(assertRes, res.text)

            return res.text,url,headers,cookies,params,body,res_status
        except Exception as e:
            print('出错了，错误是%s' % e)
            raise e


if __name__ =='__main__':
    url = '/login'
    method = "get"
    headers = ''
    cookies = ''
    params=''
    body=''
    globalVariable=''
    res = my_request(url, method, headers, cookies, params, body, globalVariable)
    print(res.text)

    p = ''
    params = eval(params) if params else params
    print('===',params)