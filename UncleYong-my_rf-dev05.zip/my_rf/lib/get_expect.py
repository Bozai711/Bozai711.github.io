#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记

def get_expect(expect_value):
    l = []
    for i in expect_value.split(';'):
        if i:
            l.append(i.split('..')[1])
    return ','.join(l)

if __name__ == '__main__':
    res = get_expect('$..code=9600;$..msg=删除成功')
    print(res)