# python版接口自动化测试框架（未使用unittest、pytest等）


## 博客及公众号
- 更多测试分享，请访问[**博客**](https://www.cnblogs.com/uncleyong/p/10530261.html)：https://www.cnblogs.com/uncleyong/p/10530261.html
- 更多测试干货，请关注：**微信公众号：全栈测试笔记**
- ![微信公众号：全栈测试笔记](https://files-cdn.cnblogs.com/files/uncleyong/qzcsbj.bmp)


## 设计思路
- 本框架没有使用常见的unittest、pytest、ddt等等，
- 实现了数据分离，excel管理用例数据（Sheet1是单接口，lc是一个简单的流程）
- 实现了关联，依赖数据放入全局变量中
- 循环执行用例，自己统计用例执行通过情况，把测试结果传给报告模板，生成报告
- 思路详见代码注释，根据实际情况调整框架


## 目录结构介绍
- bin：可执行文件，程序入口
- conf：配置文件，各种路径配置、ip、端口等
- lib：工具库
- reprot：测试报告
- data：测试数据excel
- README.md：说明文件


## 主要技术栈
- requests
- xlutils
- xlrd


## 使用说明


## 待优化功能
- **数据初始化**：比如要登录，保证有正确的账号，新增数据，要保证被新增的数据不存在；其实，业务数据基本上在流程测试过程中就依赖获取到了



## 更新历史


## 参与贡献

