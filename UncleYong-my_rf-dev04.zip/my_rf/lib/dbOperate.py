#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记

import os
import sys
path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# print(path)
sys.path.insert(0, path)
import pymysql
from conf.settings import DB_NAME
from conf.settings import DB_PASSWORD
from conf.settings import DB_IP
from conf.settings import DB


class DbOperate(object):
    __instance = None

    def __new__(cls, *args, **kwargs):
        if not cls.__instance: 
            cls.__instance = object.__new__(cls)
        return cls.__instance

    def __init__(self, sql):
        self.name = DB_NAME
        self.password = DB_PASSWORD
        self.ip = DB_IP
        self.db = DB
        self.sql = sql.strip().lower()
	
    def db_operate(self):
        '''初始化数据'''
        pass
