#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记

import xlrd
from xlutils import copy
import time,os,sys

path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, path)
from conf.settings import DATA_PATH,SHEET_NAME,SHEET_INFO


def write_excel(src_case_path,res_list):
	'''反写结果到excel'''
	src_book = xlrd.open_workbook(src_case_path)
	new_book = copy.copy(src_book)
	sheet = new_book.get_sheet(SHEET_INFO.get(SHEET_NAME))
	line = 2
	for res in res_list:
		req  = res.get('request')
		response  = res.get('response')
		status  = res.get('status')
		sheet.write(line,16,req)
		sheet.write(line,17,response)
		sheet.write(line,18,status)
		line+=1
	file_name = time.strftime('%Y-%m-%d-%H_%M_%S_')+os.path.basename(src_case_path)
	abs_path = os.path.join(DATA_PATH,file_name).replace('xlsx','xls')
	new_book.save(abs_path)