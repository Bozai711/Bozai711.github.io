#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记

import json
def if_dict_instance(obj):
    '''如果是字典，转换为json字符串'''
    if isinstance(obj, dict):
        return json.dumps(obj)
    else:
        return obj

