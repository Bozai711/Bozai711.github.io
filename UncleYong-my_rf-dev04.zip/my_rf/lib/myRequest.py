#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记


# from lib.saveGlobalVariable import save_global_variable
from lib.ifDictInstance import if_dict_instance
from lib.GlobalVariables import gv
import requests


def my_request(url, method, headers, cookies, params, body, dep, globalVariable, init_sql):
    '''请求'''
    headers = eval(headers) if headers else headers
    cookies = eval(cookies) if cookies else cookies
    params = eval(params) if params else params
    json_data = eval(body) if body else body

    if init_sql:
        pass

    # get请参考post完善
    if method.upper() == 'GET':
        try:
            res = requests.get(url=url,headers=headers, cookies=cookies, params=params,timeout=10)
            return res.text
        except Exception as e:
            return '出错了，错误是%s' % e


    elif method.upper() == 'POST':
        # 如果存在依赖数据
        if dep:
            from lib.getDep import get_dep
            dc = get_dep(dep)
            json_data.update(dc)
            print('json_data:',json_data)
        # 执行请求
        try:
            res = requests.post(url=url,headers=headers, cookies=cookies, params=params, json=json_data, timeout=10)
            # 如果有需要被后续请求用的变量数据
            if globalVariable:
                # save_global_variable(globalVariable,res.text)
                gv.save_global_variable(globalVariable,res.text)

            return res.text,if_dict_instance(headers),if_dict_instance(cookies),if_dict_instance(params),if_dict_instance(json_data)
        except Exception as e:
            return '出错了，错误是%s' % e


if __name__ =='__main__':
    url = '/login'
    method = "get"
    headers = ''
    cookies = ''
    params=''
    body=''
    globalVariable=''
    res = my_request(url, method, headers, cookies, params, body, globalVariable)
    print(res.text)

    p = ''
    params = eval(params) if params else params
    print('===',params)