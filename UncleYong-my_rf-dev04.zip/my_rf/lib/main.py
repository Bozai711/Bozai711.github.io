#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记

import time

from lib import HtmlReport
from lib.writeExcel import write_excel
from lib.readExcel import read_excel
from lib.assertRes import assert_res
from lib.myRequest import my_request


class Main():
	def __init__(self,case_path, host, sheet):
		self.case_path = case_path
		self.host = host
		self.sheet = sheet

	def __run(self):
		'''循环执行用例，保存结果'''
		start_time = time.time()
		self.all_res_list = []
		self.pass_count = 0
		case_list = read_excel(self.case_path, self.sheet)
		for case in case_list:
			res_dic = {}
			print("\n\n> > > > > > > > > > 执行case_id={}, case_name={} < < < < < < < < < <".format(case['case_id'],case['case_name']))
			req_url = self.host+case['url']  # 请求url
			print('req_url: ', req_url)
			response,headers,cookies,params,json_data = my_request(req_url, case['method'], case['headers'], case['cookies'], case['params'], case['body'], case['dep'], case['globalVariable'], case['init_sql'])
			req_params ='headers='+ headers + ' ,cookies=' + cookies +' ,params='+ params + ' ,body=' + json_data
			print('req_params: ', req_params)
			print('response: ',response)
			print('expected: ', case['expected'])
			case_status = assert_res(response, case['expected'])  # 执行结果
			print('case_status: ',case_status)
			if case_status=='pass':
				self.pass_count+=1
			res_dic={
				"case_id": case['case_id'],
				"project": case['project'],
				"model": case['module'],
				"detail": case['description'],
				"url": req_url,
				"request": req_params,
				"response": response,
				"status": case_status,
				"tester": case['tester'],
			}  # 存每条用例的结果
			self.all_res_list.append(res_dic)
			print(res_dic)
		end_time = time.time()
		self.run_time = end_time - start_time
		print('\n> > > > > > > > > > 用例执行完成 < < < < < < < < < <')

	def __result(self):
		'''反写结果到excel，以及生成报告'''
		print('\n> > > > > > > > > > 反写excel < < < < < < < < < <')
		write_excel(self.case_path, self.all_res_list)  # 反写excel
		print('\n> > > > > > > > > > 生成测试报告 < < < < < < < < < <')
		all_case_num = len(self.all_res_list)  # 总用例数
		fail_count = all_case_num - self.pass_count
		all = {
			"all": all_case_num,
			"ok": self.pass_count,
			"fail":fail_count,
			"run_time": '%.2f'%self.run_time,
			"case_res": self.all_res_list,
			"date": time.strftime('%Y/%m/%d %H:%M:%S'),
			"passRate": str('%.2f'%((self.pass_count/all_case_num)*100)) + "%"
			# "passRate": "100%"
		}
		my_report = HtmlReport.HtmlReport(all)
		my_report.report()
		print('\n> > > > > > > > > > 运行结束 < < < < < < < < < <')

	def main(self):
		self.__run()
		self.__result()


if __name__ == '__main__':
	pass