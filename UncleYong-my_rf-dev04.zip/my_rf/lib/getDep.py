#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/1/1 22:59
# @Blog    : http://www.cnblogs.com/uncleyong
# @Gitee   : https://gitee.com/uncleyong
# @QQ交流群 : 652122175
# @公众号   : 全栈测试笔记

from lib.GlobalVariables import gv

def get_dep(dep):
    '''获取依赖数据'''
    dc = {}
    for d in dep.split(";"):
        if d.strip():
            dc[d] = gv.getVar(d)
    return dc

if __name__ == '__main__':
    s = 'token;username;'
    get_dep(s)
    print(s.split(";"))